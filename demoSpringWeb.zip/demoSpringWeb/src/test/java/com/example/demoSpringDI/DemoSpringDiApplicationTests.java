package com.example.demoSpringDI;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoSpringDiApplicationTests {

	@Test
	void contextLoads() {
	}

}
