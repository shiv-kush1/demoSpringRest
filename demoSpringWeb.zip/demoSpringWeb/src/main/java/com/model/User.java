package com.model;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class User {
@Id
	private String name;
	
	private String email;
	
	private String pass;
	
	private String city;
	
	

	public User() {
		super();
		// TODO Auto-generated constructor stub
	}

	public User(String name, String email, String pass, String city) {
		super();
		this.name = name;
		this.email = email;
		this.pass = pass;
		this.city = city;
	}

	@Override
	public String toString() {
		return "User [name=" + name + ", email=" + email + ", pass=" + pass + ", city=" + city + "]";
	}
	
	
	
	
	
}
