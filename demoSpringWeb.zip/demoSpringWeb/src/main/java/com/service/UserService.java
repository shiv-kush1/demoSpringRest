package com.service;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.model.User;
import com.remo.MyRepo;

@Service
public class UserService {

	@Autowired
	private MyRepo myrepo;
	
	ArrayList<User> al=new ArrayList<User>();
	
	public boolean loginValid(String name,String pass) {
		
		if(name.equals("admin") && pass.equals("manager")) 
		{
			return true;
			
			
		}
return false;
}

	
	public void addUser(String name,String email,String pass,String city) {
		
		//al.add(new User(name,email,pass,city));
		
		myrepo.save(new User(name,email,pass,city));
		
		//System.out.println(al);
	}
	
}

